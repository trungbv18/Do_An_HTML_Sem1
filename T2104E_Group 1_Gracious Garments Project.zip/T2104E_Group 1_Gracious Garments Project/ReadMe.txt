-----GRACIOUS GARMENTS-----
I, Computer to install:
    1. WebStore or similar software
    2. Node js
    3. SQL Server 2012 
II, The instruction to run our full project:
    1.Open terminal in Webstorm
    2.Run command: Install npm express
    3.Run command: Install npm ejs
    4.Run command: Install npm mssql
    5.Run index.js file
    6.Sample account to login:
	user:admin
	password:123123
    6.In Google Chrome,access address : http://localhost:4000

III, Here is link of our product demo on herokuapp.com:
    https://garments-shop.herokuapp.com