create table Nhasx(
	TenNSX varchar(255),
	DiaChi varchar(255),
	Email text,
	DienThoai varchar(255),
	ID int primary key identity(1,1)
);

create table eSanPham(
	TenSP varchar(255),
	MoTa text,
	Gia decimal(12,3),
	SoLuonTon int,
	Img varchar(255),
	Vatlieu text,
	MaSP varchar(255),
	LuuY text,
	ID int primary key identity(1,1),
	NhaSXID int foreign key references Nhasx(ID)
);

insert into Nhasx(TenNSX,DiaChi,Email,DienThoai) values('Adidas','91074 Herzogenaurach Germany','addias.gmail.com','+49 9132 840'),
			('Nike','Washington County, Oregon, American','Nike.gmail.com','1-800-806-6453'),
			('Gucci','Florence, Italia','gucci.gmail.com','+84.28.4458.1655'),
			('Louis Vuitton','Paris, Fanch','usacareservice@contact.louisvuitton.com','+1.866.VUITTON'),
			('Dior','30 Montaigne, Paris, Franch','dior.gmail.com',' +44 (0)20 7216 02 16.');


insert into eSanPham(TenSP,MoTa,Gia,SoLuonTon,Img,Vatlieu,MaSP,LuuY,NhaSXID) values('The North Face',
	'From T-shirts and hoodies to waterproof jackets and super-cosy fleeces, the label mixes technical fabrics with a flex-worthy aesthetic � think climbing gear meets cult streetwear.'
	,400,100,'../images/sp1a.jpg','100% Nylon.','2038627','Machine wash according to instructions on care label',1),
	('ASOS Weekend ',
	'If you thought Public Desire only did shoes, we�ve got news for you. Updating its offering with a range of selfie-worthy apparel � think slinky dresses, statement co-ords and off-duty-glam tracksuits � our Public Desire at ASOS edit has your new outfit sorted'
	,500,200,'../images/sp2a.jpg','50% Cotton, 50% Polyester.','2016392','Machine wash according to instructions on care label',1),
	('ASOS DESIGN',
	'Soft, breathable jersey Made with organic cotton Grown using less water and no pesticides .It�s a win-win, improving the environment for both cotton farmers and wildlife '
	,400,50,'../images/sp3a.jpg','100% Organic Cotton.','2023903','Machine wash according to instructions on care label',1),
	('rib polo in navy',
	'This is ASOS DESIGN � your go-to for all the latest trends, no matter who you are, where you�re from and what you�re up to. Exclusive to ASOS, our universal brand is here for you, and comes in Plus and Tall. Created by us, styled by you.'
	,200,520,'../images/sp4a.jpg','95% Cotton, 5% Elastane.','104924345','Machine wash according to instructions on care label',1),
	('waffle polo',
	'This is ASOS DESIGN � your go-to for all the latest trends, no matter who you are, where you�re from and what you�re up to. Exclusive to ASOS, our universal brand is here for you, and comes in Plus and Tall. Created by us, styled by you.'
	,200,520,'../images/sp5a.jpg','95% Cotton, 5% Elastane.','104924322','Machine wash according to instructions on care label',2),
	('AllSaints Rex',
	'East London born and bred, AllSaints turned heads in the mid-90s with its investment leather jackets. Today, a collection of worn-in denim, vintage-inspired shirts and classic jersey � all boasting the iconic Ramskull logo � reflects'
	,100,120,'../images/sp6a.jpg',' 76% Cotton, 16% Polyester, 7%','109004109','Machine wash according to instructions on care label',2),
	('Originals Tennis Luxe',
	'With a history stretching back over 60 years, adidas staples have become key players in wardrobes everywhere. Scroll the adidas at ASOS edit to get your 3-Stripes fix, with everything from adidas Performance leggings and vests to adidas Originals tracksuits'
	,80,420,'../images/sp7a.jpg',' 65% Polyester, 35% Cotton.','109001109','Machine wash according to instructions on care label',2),
	(' boucle wrap',
	'This is ASOS DESIGN � your go-to for all the latest trends, no matter who you are, where you�re from and what you�re up to. Exclusive to ASOS, our universal brand is here for you, and comes in all our fit ranges'
	,90,120,'../images/sp8a.jpg',' 49% Polyester, 32% Cotton, 19% Acrylic.','105501109','Machine wash according to instructions on care label',2),
	('Missguided faux',
	'From casual daytime pieces to elevated weekend styles, add some newness to your line-up with our Missguided at ASOS edit. Filling up our social feeds and Saved Items since 2009, the brand�s collection of slogan T-shirts, crop tops, jeans'
	,190,180,'../images/sp9a.jpg',' 95% Polyester, 5% Elastane,','1054401109','Machine wash according to instructions on care label',3),
	('The North Face',
	'Founded by a pair of hiking enthusiasts, outdoor clothing and equipment brand The North Face is always ready for adventure. From T-shirts and hoodies to waterproof jackets and super-cosy fleeces, the label mixes technical fabrics with a flex-worthy aesthetic � think climbing gear meets cult streetwear.'
	,300,122,'../images/sp10a.jpg','100% Cotton.','10333109','Machine wash according to instructions on care label',3),
	('Jack & Jones Originals',
	'Founded in the 90s as a jeanswear brand, Danish label Jack & Jones has since gone on to expand its sartorial offering to include everything from jumpers, jackets and T-shirts to shoes, underwear and accessories alongside more of its flex-worthy denim, of course'
	,400,222,'../images/sp11a.jpg','60% Cotton, 40% Viscose.','20333109','Machine wash according to instructions on care label',3),
	('muscle fit',
	'This is ASOS DESIGN � your go-to for all the latest trends, no matter who you are, where you�re from and what you�re up to. Exclusive to ASOS, our universal brand is here for you, and comes in Plus and Tall. Created by us, styled by you.'
	,600,199,'../images/sp12a.jpg','100% Acrylic.','20433109','Machine wash according to instructions on care label',3),
	('knitted muscle',
	'This is ASOS DESIGN � your go-to for all the latest trends, no matter who you are, where you�re from and what you�re up to. Exclusive to ASOS, our universal brand is here for you, and comes in Plus and Tall. Created by us, styled by you.'
	,100,299,'../images/sp13a.jpg','100% Acrylic.','20436609','Machine wash according to instructions on care label',4),
	('Burton Menswear',
	'British brand Burton Menswear London combines a long heritage of tailoring with a modern take on relaxed formal and casualwear to bring an added hint of freshness to every occasion. Expect classic shirting and knitwear.'
	,300,399,'../images/sp14a.jpg','81% Organic Cotton, 19% Nylon.','30436609','Machine wash according to instructions on care label',4),
	('Petite borg collared',
	'This is ASOS DESIGN � your go-to for all the latest trends, no matter who you are, where you�re from and what you�re up to. Exclusive to ASOS, our universal brand is here for you, and comes in all our fit ranges: ASOS Curve, Tall, Petite and Maternity. Created by us, styled by you.'
	,199,50,'../images/sp15a.jpg','100% Polyester, Lining: 100%','43436609','Machine wash according to instructions on care label',4),
	('Running hooded',
	'Key players in everything activewear-related, it doesn�t get more iconic than Nike. Sporting some of the most wanted trainers in the game, browse Air Max 90s and Air Force 1s, as well as Cortez and Joyride styles. Get off-duty looks down with tracksuits, T-shirts and accessories '
	,399,10,'../images/sp16a.jpg','100% Polyester','54336609','Machine wash according to instructions on care label',4),
	('oversized maxi',
	'This is ASOS DESIGN � your go-to for all the latest trends, no matter who you are, where you�re from and what you�re up to. Exclusive to ASOS, our universal brand is here for you, and comes in all our fit ranges: ASOS Curve, Tall, Petite and Maternity. Created by us, styled by you.'
	,199,80,'../images/sp17a.jpg','100% Polyester, Shell: 64% Cotton,','24336609','Machine wash according to instructions on care label',5),
	('padded parka',
	'This is ASOS DESIGN � your go-to for all the latest trends, no matter who you are, where you�re from and what you�re up to. Exclusive to ASOS, our universal brand is here for you, and comes in all our fit ranges: ASOS Curve, Tall, Petite and Maternity. Created by us, styled by you.'
	,499,180,'../images/sp18a.jpg','100% Polyester, Shell: 100%','65436609','Machine wash according to instructions on care label',5),
	('oversized co-ord',
	'Ever since his game-changing jump shot sealed the 1982 NCAA Championship, Michael Jordan has been setting new standards in scores and style for basketball. After first wearing his original Air Jordan Is in 1985, Jordan has pushed the boundaries on and off the court with their iconic kicks, hoodies, basketball vest and sweat pants.'
	,999,280,'../images/sp19a.jpg','81% Cotton, 19% Polyester','89436609','Machine wash according to instructions on care label',5),
	('COLLUSION',
	'A new brand for the coming-of-age generation that refuses to compromise on principle or style, COLLUSION believes clothes that celebrate self-expression and inclusivity should be the norm. It�s no surprise then that it�s linked up with six inspirational creatives '
	,599,80,'../images/sp20a.jpg','100% Cotton.','89445679','Machine wash according to instructions on care label',5);